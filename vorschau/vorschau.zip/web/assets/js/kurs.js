/* Erzeugt von bauen.py aus kurs.yaml – nicht von Hand ändern. */
window.LP_KURS = {
 "titel": "Exkurs Vollkostenrechnung",
 "kurzname": "exkurs-vollkostenrechnung",
 "logoZeichen": "€",
 "anrede": "du",
 "notizfrage": "",
 "stufen": [
  {
   "id": "von-guv-zu-kosten",
   "name": "Von der GuV zu den Kosten",
   "icon": "🌱",
   "start": "g1-von-der-guv-zu-den-einzel-und-gemeinkosten.html"
  }
 ],
 "module": [
  {
   "id": "g1",
   "level": "von-guv-zu-kosten",
   "file": "g1-von-der-guv-zu-den-einzel-und-gemeinkosten.html",
   "title": "Von der GuV zu den Einzel- und Gemeinkosten",
   "min": 45,
   "milestone": false
  },
  {
   "id": "g2",
   "level": "von-guv-zu-kosten",
   "file": "g2-kostenarten-einzel-und-gemeinkosten-vertiefen-h.html",
   "title": "Kostenarten, Einzel- und Gemeinkosten vertiefen (H)",
   "min": 70,
   "milestone": false
  },
  {
   "id": "gm",
   "level": "von-guv-zu-kosten",
   "file": "gm-meilenstein-1-kostenartenplan-montelli-fur-augus.html",
   "title": "Meilenstein 1: Kostenartenplan Montelli für August",
   "min": 45,
   "milestone": true
  }
 ],
 "abgabeLink": "",
 "extras": [],
 "varianten": null,
 "menueband": {},
 "selbstcheck": null,
 "einstufung": {},
 "zugang": null
};
