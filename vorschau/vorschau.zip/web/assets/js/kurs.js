/* Erzeugt von bauen.py aus kurs.yaml – nicht von Hand ändern. */
window.LP_KURS = {
 "titel": "Exkurs Vollkostenrechnung",
 "kurzname": "exkurs-vollkostenrechnung",
 "logoZeichen": "€",
 "anrede": "du",
 "notizfrage": "",
 "stufen": [
  {
   "id": "von-guv-zu-kosten",
   "name": "Von der GuV zu den Kosten",
   "icon": "🌱",
   "start": "g1-von-der-guv-zu-den-einzel-und-gemeinkosten.html"
  },
  {
   "id": "bab",
   "name": "Der Betriebsabrechnungsbogen",
   "icon": "🚀",
   "start": "b1-der-bab-gemeinkosten-auf-kostenstellen-verteilen.html"
  }
 ],
 "module": [
  {
   "id": "g1",
   "level": "von-guv-zu-kosten",
   "file": "g1-von-der-guv-zu-den-einzel-und-gemeinkosten.html",
   "title": "Von der GuV zu den Einzel- und Gemeinkosten",
   "min": 45,
   "milestone": false
  },
  {
   "id": "g2",
   "level": "von-guv-zu-kosten",
   "file": "g2-kostenarten-einzel-und-gemeinkosten-vertiefen-h.html",
   "title": "Kostenarten, Einzel- und Gemeinkosten vertiefen (H)",
   "min": 70,
   "milestone": false
  },
  {
   "id": "gm",
   "level": "von-guv-zu-kosten",
   "file": "gm-meilenstein-1-kostenartenplan-montelli-fur-augus.html",
   "title": "Meilenstein 1: Kostenartenplan Montelli für August",
   "min": 45,
   "milestone": true
  },
  {
   "id": "b1",
   "level": "bab",
   "file": "b1-der-bab-gemeinkosten-auf-kostenstellen-verteilen.html",
   "title": "Der BAB – Gemeinkosten auf Kostenstellen verteilen",
   "min": 60,
   "milestone": false
  },
  {
   "id": "b2",
   "level": "bab",
   "file": "b2-zuschlagssatze-fur-material-und-fertigung-h.html",
   "title": "Zuschlagssätze für Material und Fertigung (H)",
   "min": 45,
   "milestone": false
  },
  {
   "id": "b3",
   "level": "bab",
   "file": "b3-der-maschinenplatz-maschinenstundensatz-und-rest.html",
   "title": "Der Maschinenplatz – Maschinenstundensatz und Restgemeinkosten",
   "min": 45,
   "milestone": false
  },
  {
   "id": "b4",
   "level": "bab",
   "file": "b4-herstellkosten-des-umsatzes-und-verwaltungs-und-.html",
   "title": "Herstellkosten des Umsatzes und Verwaltungs- und Vertriebsgemeinkosten (H)",
   "min": 45,
   "milestone": false
  },
  {
   "id": "bm",
   "level": "bab",
   "file": "bm-meilenstein-2-bab-und-zuschlagssatze-fur-august.html",
   "title": "Meilenstein 2: BAB und Zuschlagssätze für August",
   "min": 90,
   "milestone": true
  }
 ],
 "abgabeLink": "",
 "extras": [],
 "varianten": null,
 "menueband": {},
 "selbstcheck": null,
 "einstufung": {
  "bab": "einstufung-bab.html"
 },
 "zugang": null
};
