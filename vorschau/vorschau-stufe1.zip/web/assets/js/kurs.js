/* Erzeugt von bauen.py aus kurs.yaml – nicht von Hand ändern. */
window.LP_KURS = {
 "titel": "Exkurs Vollkostenrechnung",
 "kurzname": "exkurs-vollkostenrechnung",
 "logoZeichen": "€",
 "anrede": "du",
 "notizfrage": "",
 "stufen": [
  {
   "id": "von-guv-zu-kosten",
   "name": "Von der GuV zu den Kosten",
   "icon": "🌱",
   "start": "g1-warum-reicht-die-guv-nicht.html"
  }
 ],
 "module": [
  {
   "id": "g1",
   "level": "von-guv-zu-kosten",
   "file": "g1-warum-reicht-die-guv-nicht.html",
   "title": "Warum reicht die GuV nicht?",
   "min": 45,
   "milestone": false
  },
  {
   "id": "g2",
   "level": "von-guv-zu-kosten",
   "file": "g2-kostenarten-einzel-und-gemeinkosten-h.html",
   "title": "Kostenarten, Einzel- und Gemeinkosten (H)",
   "min": 60,
   "milestone": false
  },
  {
   "id": "gm",
   "level": "von-guv-zu-kosten",
   "file": "gm-meilenstein-1-kostenartenplan-montelli-fur-augus.html",
   "title": "Meilenstein 1: Kostenartenplan Montelli für August",
   "min": 45,
   "milestone": true
  }
 ],
 "abgabeLink": "",
 "extras": [],
 "varianten": null,
 "menueband": {},
 "selbstcheck": null,
 "einstufung": {},
 "zugang": null
};
